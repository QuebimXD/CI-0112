var class_veterinario =
[
    [ "Veterinario", "class_veterinario.html#a6b20a9b6948304cf705451587847e114", null ],
    [ "arbolVacio", "class_veterinario.html#a8581823b43d59b77534b8b2d2eb58c12", null ],
    [ "atender", "class_veterinario.html#a2b6618b1551cc567d638bbb40c84cd4b", null ],
    [ "buscarMascotaArbol", "class_veterinario.html#a8cd50be454e829da70103dccf52f04de", null ],
    [ "eliminarMascota", "class_veterinario.html#a52c3084536d9b685cd9ca7932b39fecd", null ],
    [ "guardarArbol", "class_veterinario.html#a389d459f0a1cc13c2cdf8d34307c685f", null ],
    [ "ingresarCola", "class_veterinario.html#a819c47c5b1374c2bc9e00c8fa3bb57c2", null ],
    [ "mostrarAtendida", "class_veterinario.html#ae8271f3340d0f091c20b449170d0c761", null ],
    [ "mostrarColaa", "class_veterinario.html#a1a24409573b883bafdf2eb5dcb2529df", null ],
    [ "mostrarMascota", "class_veterinario.html#a23f92feba7ec831c4a65040f7bdf7a13", null ],
    [ "registrar", "class_veterinario.html#ac75b18e2d9c838ec5b1cea750d820f3e", null ],
    [ "verHistoria", "class_veterinario.html#af6647f6d825c733be65706aebf8bf9d1", null ]
];