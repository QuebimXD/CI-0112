var class_nodo_mascota_cola =
[
    [ "NodoMascotaCola", "class_nodo_mascota_cola.html#af192c33ca6809137ed67b6644019400d", null ],
    [ "getMascota", "class_nodo_mascota_cola.html#a3b1368e64b0547d206d8bae983f58b3c", null ]
];