var class_cola_mascota =
[
    [ "ColaMascota", "class_cola_mascota.html#a239dffa728dd074d802f2cfd856c18f0", null ],
    [ "contiene", "class_cola_mascota.html#ae2b88cf559414da7c9c1494557ea55f3", null ],
    [ "dequeue", "class_cola_mascota.html#a42ef5c136faa35c6ae8bcdd1b33b8327", null ],
    [ "enqueue", "class_cola_mascota.html#ad57ae6be6588eff58437f3d5bf0845ac", null ],
    [ "estaVacia", "class_cola_mascota.html#a2f56341ba6c5ceaa3f52b8ee671a173d", null ],
    [ "mostrarCola", "class_cola_mascota.html#a7b619b2c1885497ee0736a2f248c2636", null ],
    [ "peek", "class_cola_mascota.html#add6f6e0e5f63628a432e1a1efaac99b5", null ]
];