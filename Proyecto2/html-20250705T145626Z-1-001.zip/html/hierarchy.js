var hierarchy =
[
    [ "ArbolMascota", "class_arbol_mascota.html", null ],
    [ "ColaMascota", "class_cola_mascota.html", null ],
    [ "JFrame", null, [
      [ "InterfazGrafica", "class_interfaz_grafica.html", null ]
    ] ],
    [ "Mascota", "class_mascota.html", null ],
    [ "NodoMascotaABB", "class_nodo_mascota_a_b_b.html", null ],
    [ "NodoMascotaCola", "class_nodo_mascota_cola.html", null ],
    [ "Veterinario", "class_veterinario.html", null ]
];