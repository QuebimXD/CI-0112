var annotated_dup =
[
    [ "ArbolMascota", "class_arbol_mascota.html", "class_arbol_mascota" ],
    [ "ColaMascota", "class_cola_mascota.html", "class_cola_mascota" ],
    [ "InterfazGrafica", "class_interfaz_grafica.html", "class_interfaz_grafica" ],
    [ "Mascota", "class_mascota.html", "class_mascota" ],
    [ "NodoMascotaABB", "class_nodo_mascota_a_b_b.html", "class_nodo_mascota_a_b_b" ],
    [ "NodoMascotaCola", "class_nodo_mascota_cola.html", "class_nodo_mascota_cola" ],
    [ "Veterinario", "class_veterinario.html", "class_veterinario" ]
];