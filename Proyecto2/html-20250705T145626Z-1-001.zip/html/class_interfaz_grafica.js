var class_interfaz_grafica =
[
    [ "InterfazGrafica", "class_interfaz_grafica.html#a54d57ed203939316d8c8a0e4e27c611a", null ],
    [ "tieneEntero", "class_interfaz_grafica.html#a864282732764768c1f6af8a247be9904", null ]
];