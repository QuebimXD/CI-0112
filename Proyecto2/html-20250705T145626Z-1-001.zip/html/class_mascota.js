var class_mascota =
[
    [ "Mascota", "class_mascota.html#a9113c8519e681535e7aeac05a831f01a", null ],
    [ "getId", "class_mascota.html#a9668108dc9e4e140097b124593513912", null ]
];