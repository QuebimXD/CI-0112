var class_nodo_mascota_a_b_b =
[
    [ "NodoMascotaABB", "class_nodo_mascota_a_b_b.html#aa1aa1b85194cb30d9a7663442363b475", null ],
    [ "getDatoMascota", "class_nodo_mascota_a_b_b.html#a26ba4fa0d4af9838f1b03f93f004a7cd", null ]
];