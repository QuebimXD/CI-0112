var searchData=
[
  ['recorridoinordengui_0',['recorridoInOrdenGui',['../class_arbol_mascota.html#a0785a67b9d05d02815cded55ed57e6a3',1,'ArbolMascota']]],
  ['registrar_1',['registrar',['../class_veterinario.html#ac75b18e2d9c838ec5b1cea750d820f3e',1,'Veterinario']]],
  ['registro_2',['Registro',['../md__r_e_a_d_m_e.html#autotoc_md3',1,'']]]
];
