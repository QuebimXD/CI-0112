var searchData=
[
  ['de_20cola_20de_20mascotas_3a_0',['Botones de Cola de Mascotas:',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'']]],
  ['de_20mascotas_1',['de Mascotas',['../md__r_e_a_d_m_e.html#autotoc_md7',1,'Cola de Mascotas'],['../md__r_e_a_d_m_e.html#autotoc_md5',1,'Historial de Mascotas']]],
  ['de_20mascotas_3a_2',['Botones de Cola de Mascotas:',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'']]],
  ['dequeue_3',['dequeue',['../class_cola_mascota.html#a42ef5c136faa35c6ae8bcdd1b33b8327',1,'ColaMascota']]]
];
