var searchData=
[
  ['buscarmascotaarbol_0',['buscarMascotaArbol',['../class_veterinario.html#a8cd50be454e829da70103dccf52f04de',1,'Veterinario']]],
  ['buscarmascotagui_1',['buscarMascotaGui',['../class_arbol_mascota.html#a137ef78f689cb050c718bee56e6d6f10',1,'ArbolMascota']]]
];
