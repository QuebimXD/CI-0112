var searchData=
[
  ['verhistoria_0',['verHistoria',['../class_veterinario.html#af6647f6d825c733be65706aebf8bf9d1',1,'Veterinario']]],
  ['veterinaria_1',['Proyecto 2: Clínica Veterinaria',['../md__r_e_a_d_m_e.html',1,'']]],
  ['veterinario_2',['Veterinario',['../class_veterinario.html',1,'Veterinario'],['../class_veterinario.html#a6b20a9b6948304cf705451587847e114',1,'Veterinario.Veterinario()']]]
];
