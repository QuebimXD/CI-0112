var searchData=
[
  ['getdatomascota_0',['getDatoMascota',['../class_nodo_mascota_a_b_b.html#a26ba4fa0d4af9838f1b03f93f004a7cd',1,'NodoMascotaABB']]],
  ['getid_1',['getId',['../class_mascota.html#a9668108dc9e4e140097b124593513912',1,'Mascota']]],
  ['getmascota_2',['getMascota',['../class_nodo_mascota_cola.html#a3b1368e64b0547d206d8bae983f58b3c',1,'NodoMascotaCola']]],
  ['getraiz_3',['getRaiz',['../class_arbol_mascota.html#a169888bd6d205d30d7a8782d7d5d04d6',1,'ArbolMascota']]],
  ['guardararbol_4',['guardarArbol',['../class_veterinario.html#a389d459f0a1cc13c2cdf8d34307c685f',1,'Veterinario']]]
];
