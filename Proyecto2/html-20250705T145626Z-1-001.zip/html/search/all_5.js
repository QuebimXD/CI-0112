var searchData=
[
  ['eliminargui_0',['eliminarGui',['../class_arbol_mascota.html#a6c4111b6ffe2c4469e4fe32ee5d2f7fb',1,'ArbolMascota']]],
  ['eliminarmascota_1',['eliminarMascota',['../class_veterinario.html#a52c3084536d9b685cd9ca7932b39fecd',1,'Veterinario']]],
  ['enqueue_2',['enqueue',['../class_cola_mascota.html#ad57ae6be6588eff58437f3d5bf0845ac',1,'ColaMascota']]],
  ['estavacia_3',['estaVacia',['../class_cola_mascota.html#a2f56341ba6c5ceaa3f52b8ee671a173d',1,'ColaMascota']]],
  ['estavacio_4',['estaVacio',['../class_arbol_mascota.html#a01882ee76a9b891c6439495360421492',1,'ArbolMascota']]]
];
