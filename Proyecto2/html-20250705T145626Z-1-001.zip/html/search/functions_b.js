var searchData=
[
  ['tieneentero_0',['tieneEntero',['../class_interfaz_grafica.html#a864282732764768c1f6af8a247be9904',1,'InterfazGrafica']]]
];
