var searchData=
[
  ['verhistoria_0',['verHistoria',['../class_veterinario.html#af6647f6d825c733be65706aebf8bf9d1',1,'Veterinario']]],
  ['veterinario_1',['Veterinario',['../class_veterinario.html#a6b20a9b6948304cf705451587847e114',1,'Veterinario']]]
];
