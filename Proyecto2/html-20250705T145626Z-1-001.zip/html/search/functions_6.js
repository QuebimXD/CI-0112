var searchData=
[
  ['ingresarcola_0',['ingresarCola',['../class_veterinario.html#a819c47c5b1374c2bc9e00c8fa3bb57c2',1,'Veterinario']]],
  ['insertargui_1',['insertarGui',['../class_arbol_mascota.html#ac6fd50cde33f8633e6d8b1f5e094d36c',1,'ArbolMascota']]],
  ['interfazgrafica_2',['InterfazGrafica',['../class_interfaz_grafica.html#a54d57ed203939316d8c8a0e4e27c611a',1,'InterfazGrafica']]]
];
