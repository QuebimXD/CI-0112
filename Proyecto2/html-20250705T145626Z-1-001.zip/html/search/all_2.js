var searchData=
[
  ['básicas_0',['Instrucciones básicas',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'']]],
  ['botones_20de_20cola_20de_20mascotas_3a_1',['Botones de Cola de Mascotas:',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'']]],
  ['buscarmascotaarbol_2',['buscarMascotaArbol',['../class_veterinario.html#a8cd50be454e829da70103dccf52f04de',1,'Veterinario']]],
  ['buscarmascotagui_3',['buscarMascotaGui',['../class_arbol_mascota.html#a137ef78f689cb050c718bee56e6d6f10',1,'ArbolMascota']]]
];
